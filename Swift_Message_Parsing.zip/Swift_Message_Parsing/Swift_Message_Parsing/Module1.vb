﻿Imports System
Imports System.ComponentModel
Imports System.IO
Imports System.Threading
Imports System.Text.RegularExpressions
Imports System.Data.SqlClient
Module Module1
    'SWIFT MESSAGE TEXT (without Header and Trailer blocks)
    Dim SwiftMessageText As String = Nothing
    Dim SwiftMessageFormatedText As String = Nothing
    Dim SwiftMessageFileName As String = Nothing

    'SWIFT MESSAGE TEXT BODY
    Dim RegexPatern As String = Nothing
    Dim RegexInput As String = Nothing

    Dim RegexSd As Array
    Dim RegexMyIndex As Integer

    Dim conn As New SqlConnection
    Dim cmd As New SqlCommand

    Public QueryText As String = Nothing
    Public SqlCommandText As String = Nothing
    Public SqlCommandText1 As String = Nothing
    Public SqlCommandText2 As String = Nothing

    Public da As SqlDataAdapter
    Public dt As System.Data.DataTable
    Public da1 As SqlDataAdapter
    Public dt1 As System.Data.DataTable
    Public da2 As SqlDataAdapter
    Public dt2 As System.Data.DataTable

    Dim ID_ORIG As Integer = 0
    Dim MESSAGE_ID As String = Nothing
    Dim MESSAGE_TYPE As String = Nothing
    Sub Main()

        conn.ConnectionString = "server=VFRA01VDI001\SQLEXPRESS;Integrated Security=SSPI; database=PDataToolDb; Connect timeout=50000"
        cmd.Connection = conn
        cmd.CommandTimeout = 50000

        'Establish connection with database
        If cmd.Connection.State <> ConnectionState.Open Then
            cmd.Connection.Open()
        End If

        'Get Swift Messages from Database
        QueryText = "Select * FROM [CALYPSO_PAYMENTS] where  ((IntermediaryInstitution is NULL and AccountWithInstitution is NULL and BeneficiaryInstitution is NULL) and MESSAGE_TYPE in ('202'))
                                                      or     ((IntermediaryInstitution is NULL and AccountWithInstitution is NULL) and MESSAGE_TYPE in ('103'))"
        'QueryText = "Select * FROM [CALYPSO_PAYMENTS] where  ID=663"
        da = New SqlDataAdapter(QueryText.Trim(), conn)
        dt = New System.Data.DataTable()
        da.Fill(dt)
        For i = 0 To dt.Rows.Count - 1
            ID_ORIG = CInt(dt.Rows.Item(i).Item("ID").ToString)
            MESSAGE_ID = dt.Rows.Item(i).Item("MESSAGE_ID").ToString
            MESSAGE_TYPE = dt.Rows.Item(i).Item("MESSAGE_TYPE").ToString
            SwiftMessageText = dt.Rows.Item(i).Item("VTB_SwiftMessageText").ToString


            cmd.CommandText = "DELETE FROM [SWIFT_MESSAGE_FIELDS]
                               TRUNCATE TABLE [SWIFT_MESSAGE_FIELDS]"
            cmd.ExecuteNonQuery()

            Console.WriteLine("Read Message_ID:" & MESSAGE_ID)

            Dim aLine As String, aParagraph As String = Nothing
            Dim strReader As StringReader = New StringReader(SwiftMessageText)
            Dim flag As Boolean = True
            aLine = strReader.ReadLine()
            While (flag = True)
                aLine = strReader.ReadLine()
                If aLine Is Nothing Then
                    flag = False

                Else
                    'Console.WriteLine("Read and import Field:" & aLine.ToString)
                    cmd.CommandText = "INSERT INTO [SWIFT_MESSAGE_FIELDS](ID_ORIGIN,[SwiftField],MESSAGE_TYPE) Values (@ID_ORIGIN_VALUE,@SwiftFieldValue,@MESSAGE_TYPE)"
                    cmd.Parameters.Add("@ID_ORIGIN_VALUE", SqlDbType.NVarChar).Value = ID_ORIG
                    cmd.Parameters.Add("@SwiftFieldValue", SqlDbType.NVarChar).Value = aLine.ToString
                    cmd.Parameters.Add("@MESSAGE_TYPE", SqlDbType.NVarChar).Value = MESSAGE_TYPE
                    cmd.ExecuteNonQuery()
                    cmd.Parameters.Clear()
                    'Update Swift Field Tags
                    cmd.CommandText = "UPDATE SWIFT_MESSAGE_FIELDS SET SwiftFieldTag=[dbo].[GetStringPartByDelimeter]([SwiftField],':',2)"
                    cmd.ExecuteNonQuery()
                    'Update missing Swift Field Tags
                    cmd.CommandText = "UPDATE t1
                                        set t1.SwiftFieldTag = t3.SwiftFieldTag
                                        from SWIFT_MESSAGE_FIELDS t1 join
                                            (Select t1.ID, max(t2.ID) max_id
                                            from SWIFT_MESSAGE_FIELDS t1
                                            join SWIFT_MESSAGE_FIELDS t2 on t1.ID > t2.ID
                                            and t2.SwiftFieldTag is not null
                                            and t1.SwiftFieldTag is null
                                            group by t1.ID) t2 on t2.ID = t1.ID
                                        join SWIFT_MESSAGE_FIELDS t3 on t3.ID = t2.max_id"
                    cmd.ExecuteNonQuery()
                    'Thread.Sleep(100)  
                End If

            End While
            'Delete Last Row - Insuficient Value
            Console.WriteLine("Delete last imported SWIFT Line")
            cmd.CommandText = "DELETE FROM [SWIFT_MESSAGE_FIELDS] WHERE ID=(SELECT MAX(ID) FROM [SWIFT_MESSAGE_FIELDS])"
            cmd.ExecuteNonQuery()
            'Update Ordering Customer
            Console.WriteLine("Parse Swift Field 50 - Ordering Customer")
            cmd.CommandText = "DECLARE @SWIFT_TAG_ID int=(Select TOP 1 ID from SWIFT_MESSAGE_FIELDS where SwiftFieldTag in ('50A','50F','50K') and [MESSAGE_TYPE] in ('103'))
                            
                                IF @SWIFT_TAG_ID is not NULL
                                BEGIN
                                DECLARE @SWIFT_TAG_FIELD_NAME nvarchar(5)=(SELECT SwiftFieldTag from SWIFT_MESSAGE_FIELDS where ID=@SWIFT_TAG_ID)
                            
                                DECLARE @SWIFT_TAG_ACCOUNT_ID int=(Select ID from SWIFT_MESSAGE_FIELDS where LEFT(SwiftField,5) in(':' + @SWIFT_TAG_FIELD_NAME +':'))

                                IF @SWIFT_TAG_ACCOUNT_ID is not NULL and @SWIFT_TAG_FIELD_NAME like '%A'
	                                BEGIN
	                               
									UPDATE A SET A.OrderingCustomerAccount=[dbo].[GetStringPartByDelimeter](B.[SwiftField],':',3) 
									from CALYPSO_PAYMENTS A INNER JOIN SWIFT_MESSAGE_FIELDS B on A.ID =B.ID_ORIGIN
									WHERE B.ID=@SWIFT_TAG_ACCOUNT_ID and @SWIFT_TAG_FIELD_NAME like '%A'

									UPDATE A SET A.OrderingCustomerNameAddress=B.[SwiftField]
									from CALYPSO_PAYMENTS A INNER JOIN SWIFT_MESSAGE_FIELDS B on A.ID =B.ID_ORIGIN
									WHERE B.ID=@SWIFT_TAG_ACCOUNT_ID+1 and @SWIFT_TAG_FIELD_NAME like '%A'

	                                END
                                IF @SWIFT_TAG_ACCOUNT_ID is not NULL and @SWIFT_TAG_FIELD_NAME not like '%A'
	                                BEGIN
									
									UPDATE A SET A.OrderingCustomerAccount=[dbo].[GetStringPartByDelimeter](B.[SwiftField],':',3) 
									from CALYPSO_PAYMENTS A INNER JOIN SWIFT_MESSAGE_FIELDS B on A.ID =B.ID_ORIGIN
									WHERE B.ID=@SWIFT_TAG_ACCOUNT_ID

									UPDATE A SET A.OrderingCustomerNameAddress=B.OrderingCustomerNameAddress from CALYPSO_PAYMENTS A INNER JOIN 
									(SELECT ID_ORIGIN,
		                                STUFF((
			                                SELECT ' ' + t2.[SwiftField]
			                                FROM [SWIFT_MESSAGE_FIELDS] t2
			                                WHERE SwiftFieldTag in (@SWIFT_TAG_FIELD_NAME) and ID>@SWIFT_TAG_ACCOUNT_ID
			                                FOR XML PATH (''))
		                                  ,1,0,'') AS OrderingCustomerNameAddress
		                                FROM [SWIFT_MESSAGE_FIELDS] t1
		                                 WHERE SwiftFieldTag in (@SWIFT_TAG_FIELD_NAME)
										 GROUP BY ID_ORIGIN,SwiftFieldTag)
										 B on A.ID =B.ID_ORIGIN
	                       
                                END
                                END"
            cmd.ExecuteNonQuery()

            'Update Intermediary Institution
            Console.WriteLine("Parse Swift Field 56 - Intermediary Institution")
            cmd.CommandText = "DECLARE @SWIFT_TAG_ID int=(Select TOP 1 ID from SWIFT_MESSAGE_FIELDS where SwiftFieldTag in ('56A','56C','56D'))
                                
                                IF @SWIFT_TAG_ID is not NULL
                                BEGIN
                                DECLARE @SWIFT_TAG_FIELD_NAME nvarchar(5)=(SELECT SwiftFieldTag from SWIFT_MESSAGE_FIELDS where ID=@SWIFT_TAG_ID)
                                
                                DECLARE @SWIFT_TAG_ACCOUNT_ID int=(Select ID from SWIFT_MESSAGE_FIELDS where LEFT(SwiftField,6) in(':' + @SWIFT_TAG_FIELD_NAME +':/'))
                                IF @SWIFT_TAG_ACCOUNT_ID is not NULL and @SWIFT_TAG_FIELD_NAME like '%A'
	                                BEGIN
	                                UPDATE A SET A.IntermediaryInstitution=B.[SwiftField] from CALYPSO_PAYMENTS A INNER JOIN SWIFT_MESSAGE_FIELDS B on A.ID =B.ID_ORIGIN
	                                WHERE B.ID=@SWIFT_TAG_ACCOUNT_ID+1 and @SWIFT_TAG_FIELD_NAME like '%A'
	                                END
                                IF @SWIFT_TAG_ACCOUNT_ID is NULL and @SWIFT_TAG_FIELD_NAME like '%A'
	                                BEGIN
	                                UPDATE A SET A.IntermediaryInstitution=[dbo].[GetStringPartByDelimeter](B.[SwiftField],':',3) from CALYPSO_PAYMENTS A INNER JOIN SWIFT_MESSAGE_FIELDS B on A.ID =B.ID_ORIGIN
	                                WHERE B.ID=@SWIFT_TAG_ID and @SWIFT_TAG_FIELD_NAME like '%A'
	                                END
                                IF @SWIFT_TAG_FIELD_NAME not like '%A'
                                BEGIN
                                UPDATE A SET A.IntermediaryInstitution=B.IntermediaryInstitution from CALYPSO_PAYMENTS A INNER JOIN 
                                (SELECT ID_ORIGIN,
		                                STUFF((
			                                SELECT '' + t2.[SwiftField]
			                                FROM [SWIFT_MESSAGE_FIELDS] t2
			                                WHERE SwiftFieldTag in (@SWIFT_TAG_FIELD_NAME)
			                                FOR XML PATH (''))
		                                  ,1,0,'') AS IntermediaryInstitution
		                                FROM [SWIFT_MESSAGE_FIELDS] t1
		                                 WHERE SwiftFieldTag in (@SWIFT_TAG_FIELD_NAME)
		                                GROUP BY ID_ORIGIN,SwiftFieldTag) B on A.ID =B.ID_ORIGIN

                                END
                                END"
            cmd.ExecuteNonQuery()

            'Update AccountWithInstitution
            Console.WriteLine("Parse Swift Field 57 - AccountWithInstitution")
            cmd.CommandText = "DECLARE @SWIFT_TAG_ID int=(Select TOP 1 ID from SWIFT_MESSAGE_FIELDS where SwiftFieldTag in ('57A','57B','57C','57D'))

                                IF @SWIFT_TAG_ID is not NULL
                                BEGIN
                                DECLARE @SWIFT_TAG_FIELD_NAME nvarchar(5)=(SELECT SwiftFieldTag from SWIFT_MESSAGE_FIELDS where ID=@SWIFT_TAG_ID)
                                select @SWIFT_TAG_FIELD_NAME
                                DECLARE @SWIFT_TAG_ACCOUNT_ID int=(Select ID from SWIFT_MESSAGE_FIELDS where LEFT(SwiftField,6) in(':' + @SWIFT_TAG_FIELD_NAME +':/'))
                                IF @SWIFT_TAG_ACCOUNT_ID is not NULL and @SWIFT_TAG_FIELD_NAME like '%A'
	                                BEGIN
	                                UPDATE A SET A.AccountWithInstitution=B.[SwiftField] from CALYPSO_PAYMENTS A INNER JOIN SWIFT_MESSAGE_FIELDS B on A.ID =B.ID_ORIGIN
	                                WHERE B.ID=@SWIFT_TAG_ACCOUNT_ID+1 and @SWIFT_TAG_FIELD_NAME like '%A'
	                                END
                                IF @SWIFT_TAG_ACCOUNT_ID is NULL and @SWIFT_TAG_FIELD_NAME like '%A'
	                                BEGIN
	                                UPDATE A SET A.AccountWithInstitution=[dbo].[GetStringPartByDelimeter](B.[SwiftField],':',3) from CALYPSO_PAYMENTS A INNER JOIN SWIFT_MESSAGE_FIELDS B on A.ID =B.ID_ORIGIN
	                                WHERE B.ID=@SWIFT_TAG_ID and @SWIFT_TAG_FIELD_NAME like '%A'
	                                END
                                IF @SWIFT_TAG_FIELD_NAME not like '%A'
                                BEGIN
                                UPDATE A SET A.AccountWithInstitution=B.AccountWithInstitution from CALYPSO_PAYMENTS A INNER JOIN 
                                (SELECT ID_ORIGIN,
		                                STUFF((
			                                SELECT '' + t2.[SwiftField]
			                                FROM [SWIFT_MESSAGE_FIELDS] t2
			                                WHERE SwiftFieldTag in (@SWIFT_TAG_FIELD_NAME)
			                                FOR XML PATH (''))
		                                  ,1,0,'') AS AccountWithInstitution
		                                FROM [SWIFT_MESSAGE_FIELDS] t1
		                                 WHERE SwiftFieldTag in (@SWIFT_TAG_FIELD_NAME)
		                                GROUP BY ID_ORIGIN,SwiftFieldTag) B on A.ID =B.ID_ORIGIN

                                END
                                END"
            cmd.ExecuteNonQuery()


            'Update Beneficiary Institution
            Console.WriteLine("Parse Swift Field 58 - BeneficiaryInstitution")
            cmd.CommandText = "DECLARE @SWIFT_TAG_ID int=(Select TOP 1 ID from SWIFT_MESSAGE_FIELDS where SwiftFieldTag in ('58A','58D') and [MESSAGE_TYPE] in ('202'))
                            
                            IF @SWIFT_TAG_ID is not NULL
                            BEGIN
                            DECLARE @SWIFT_TAG_FIELD_NAME nvarchar(5)=(SELECT SwiftFieldTag from SWIFT_MESSAGE_FIELDS where ID=@SWIFT_TAG_ID)
                            
                            DECLARE @SWIFT_TAG_ACCOUNT_ID int=(Select ID from SWIFT_MESSAGE_FIELDS where LEFT(SwiftField,6) in(':' + @SWIFT_TAG_FIELD_NAME +':/'))
                            IF @SWIFT_TAG_ACCOUNT_ID is not NULL and @SWIFT_TAG_FIELD_NAME like '%A'
	                            BEGIN
	                            UPDATE A SET A.BeneficiaryInstitution=B.[SwiftField] from CALYPSO_PAYMENTS A INNER JOIN SWIFT_MESSAGE_FIELDS B on A.ID =B.ID_ORIGIN
	                            WHERE B.ID=@SWIFT_TAG_ACCOUNT_ID+1 and @SWIFT_TAG_FIELD_NAME like '%A'
	                            END
                            IF @SWIFT_TAG_ACCOUNT_ID is NULL and @SWIFT_TAG_FIELD_NAME like '%A'
	                            BEGIN
	                            UPDATE A SET A.BeneficiaryInstitution=[dbo].[GetStringPartByDelimeter](B.[SwiftField],':',3) from CALYPSO_PAYMENTS A INNER JOIN SWIFT_MESSAGE_FIELDS B on A.ID =B.ID_ORIGIN
	                            WHERE B.ID=@SWIFT_TAG_ID and @SWIFT_TAG_FIELD_NAME like '%A'
	                            END
                            IF @SWIFT_TAG_FIELD_NAME not like '%A'
                                BEGIN
                                    UPDATE A SET A.BeneficiaryInstitution=B.BeneficiaryInstitution from CALYPSO_PAYMENTS A INNER JOIN 
                                    (SELECT ID_ORIGIN,
		                                    STUFF((
			                                    SELECT '' + t2.[SwiftField]
			                                    FROM [SWIFT_MESSAGE_FIELDS] t2
			                                    WHERE SwiftFieldTag in (@SWIFT_TAG_FIELD_NAME)
			                                    FOR XML PATH (''))
		                                      ,1,0,'') AS BeneficiaryInstitution
		                                    FROM [SWIFT_MESSAGE_FIELDS] t1
		                                     WHERE SwiftFieldTag in (@SWIFT_TAG_FIELD_NAME)
		                                    GROUP BY ID_ORIGIN,SwiftFieldTag) B on A.ID =B.ID_ORIGIN

                                END
                            END"
            cmd.ExecuteNonQuery()

            'Update Beneficiary
            Console.WriteLine("Parse Swift Field 59 - Beneficiary Customer")
            cmd.CommandText = " DECLARE @SWIFT_TAG_ID int=(Select TOP 1 ID from SWIFT_MESSAGE_FIELDS where SwiftFieldTag in ('59','59A','59F') and [MESSAGE_TYPE] in ('103'))
                             
                                IF @SWIFT_TAG_ID is not NULL
                                BEGIN
                                DECLARE @SWIFT_TAG_FIELD_NAME nvarchar(5)=(SELECT SwiftFieldTag from SWIFT_MESSAGE_FIELDS where ID=@SWIFT_TAG_ID)
                              
                                DECLARE @SWIFT_TAG_ACCOUNT_ID int=(Select ID from SWIFT_MESSAGE_FIELDS where LEFT(SwiftField,5) in(':' + @SWIFT_TAG_FIELD_NAME +':'))

                                IF @SWIFT_TAG_ACCOUNT_ID is not NULL and @SWIFT_TAG_FIELD_NAME like '%A'
	                                BEGIN
	                               
									UPDATE A SET A.BeneficiaryCustomerAccount=[dbo].[GetStringPartByDelimeter](B.[SwiftField],':',3) 
									from CALYPSO_PAYMENTS A INNER JOIN SWIFT_MESSAGE_FIELDS B on A.ID =B.ID_ORIGIN
									WHERE B.ID=@SWIFT_TAG_ACCOUNT_ID and @SWIFT_TAG_FIELD_NAME like '%A'

									UPDATE A SET A.BeneficiaryCustomerNameAddress=B.[SwiftField]
									from CALYPSO_PAYMENTS A INNER JOIN SWIFT_MESSAGE_FIELDS B on A.ID =B.ID_ORIGIN
									WHERE B.ID=@SWIFT_TAG_ACCOUNT_ID+1 and @SWIFT_TAG_FIELD_NAME like '%A'

	                                END
                                IF @SWIFT_TAG_ACCOUNT_ID is not NULL and @SWIFT_TAG_FIELD_NAME not like '%A'
	                                BEGIN
									
									UPDATE A SET A.BeneficiaryCustomerAccount=[dbo].[GetStringPartByDelimeter](B.[SwiftField],':',3) 
									from CALYPSO_PAYMENTS A INNER JOIN SWIFT_MESSAGE_FIELDS B on A.ID =B.ID_ORIGIN
									WHERE B.ID=@SWIFT_TAG_ACCOUNT_ID

									UPDATE A SET A.BeneficiaryCustomerNameAddress=B.BeneficiaryCustomerNameAddress from CALYPSO_PAYMENTS A INNER JOIN 
									(SELECT ID_ORIGIN,
		                                STUFF((
			                                SELECT ' ' + t2.[SwiftField]
			                                FROM [SWIFT_MESSAGE_FIELDS] t2
			                                WHERE SwiftFieldTag in (@SWIFT_TAG_FIELD_NAME) and ID>@SWIFT_TAG_ACCOUNT_ID
			                                FOR XML PATH (''))
		                                  ,1,0,'') AS BeneficiaryCustomerNameAddress
		                                FROM [SWIFT_MESSAGE_FIELDS] t1
		                                 WHERE SwiftFieldTag in (@SWIFT_TAG_FIELD_NAME)
										 GROUP BY ID_ORIGIN,SwiftFieldTag)
										 B on A.ID =B.ID_ORIGIN
	                       
                                END
                                END"
            cmd.ExecuteNonQuery()

            'Update Remmitance Info
            Console.WriteLine("Parse Swift Field 70 - Remmitance Info")
            cmd.CommandText = "DECLARE @SWIFT_TAG_ID int=(Select TOP 1 ID from SWIFT_MESSAGE_FIELDS where SwiftFieldTag in ('70'))

                                IF @SWIFT_TAG_ID is not NULL
                                BEGIN
                                DECLARE @SWIFT_TAG_FIELD_NAME nvarchar(5)=(SELECT SwiftFieldTag from SWIFT_MESSAGE_FIELDS where ID=@SWIFT_TAG_ID)
                             
                                DECLARE @SWIFT_TAG_ACCOUNT_ID int=(Select ID from SWIFT_MESSAGE_FIELDS where LEFT(SwiftField,5) in(':' + @SWIFT_TAG_FIELD_NAME +':'))


							    UPDATE A SET A.RemmitanceInfo=B.RemmitanceInfo from CALYPSO_PAYMENTS A INNER JOIN 
							    (SELECT ID_ORIGIN,
		                                    STUFF((
			                                    SELECT ' ' +  REPLACE(t2.[SwiftField],':' + @SWIFT_TAG_FIELD_NAME +':','')
			                                    FROM [SWIFT_MESSAGE_FIELDS] t2
			                                    WHERE SwiftFieldTag in (@SWIFT_TAG_FIELD_NAME) 
			                                    FOR XML PATH (''))
		                                      ,1,0,'') AS RemmitanceInfo
		                                    FROM [SWIFT_MESSAGE_FIELDS] t1
		                                     WHERE SwiftFieldTag in (@SWIFT_TAG_FIELD_NAME)
										     GROUP BY ID_ORIGIN,SwiftFieldTag)
										     B on A.ID =B.ID_ORIGIN
                               
							
                                    END"
            cmd.ExecuteNonQuery()


        Next

        'For MT103 Set AccountWithinstitution=ReceiverBIC where AccountWithInstitution is missing
        Console.WriteLine("For MT103 Set AccountWithinstitution=ReceiverBIC where AccountWithInstitution is missing")
        cmd.CommandText = "UPDATE CALYPSO_PAYMENTS SET AccountWithInstitution=Receiver_Address_Code where AccountWithInstitution is NULL and MESSAGE_TYPE in ('103')"
        cmd.ExecuteNonQuery()

        'Update Institution Fields and Country Fields from SYNONYMS
        Console.WriteLine("Update Institution Fields and Country Fields from SYNONYMS - Field 56")
        cmd.CommandText = "UPDATE A SET A.Field_56A=B.Synonyme_BIC,A.Country_56A=B.Synonyme_Country 
                            from CALYPSO_PAYMENTS A INNER JOIN CALYPSO_PAYMENTS_SYNONYME B on A.IntermediaryInstitution=B.SwiftField
                            where A.IntermediaryInstitution like':56%' and A.Country_56A is NULL

                            UPDATE CALYPSO_PAYMENTS SET Field_56A=IntermediaryInstitution,Country_56A=SUBSTRING(IntermediaryInstitution,5,2)
                            where ISNULL(IntermediaryInstitution,'') not like':56%' and LEN(IntermediaryInstitution)>=6 and Country_56A is NULL"
        cmd.ExecuteNonQuery()

        Console.WriteLine("Update Institution Fields and Country Fields from SYNONYMS - Field 57")
        cmd.CommandText = "UPDATE A SET A.Field_57A=B.Synonyme_BIC,A.Country_57A=B.Synonyme_Country 
                            from CALYPSO_PAYMENTS A INNER JOIN CALYPSO_PAYMENTS_SYNONYME B on A.AccountWithInstitution=B.SwiftField
                            where A.AccountWithInstitution like':57%' and A.Country_57A is NULL

                            UPDATE CALYPSO_PAYMENTS SET Field_57A=AccountWithInstitution,Country_57A=SUBSTRING(AccountWithInstitution,5,2)
                            where ISNULL(AccountWithInstitution,'') not like':57%' and LEN(AccountWithInstitution)>=6 and Country_57A is NULL"
        cmd.ExecuteNonQuery()

        Console.WriteLine("Update Institution Fields and Country Fields from SYNONYMS - Field 58")
        cmd.CommandText = "UPDATE A SET A.Field_58A=B.Synonyme_BIC,A.Country_58A=B.Synonyme_Country 
                            from CALYPSO_PAYMENTS A INNER JOIN CALYPSO_PAYMENTS_SYNONYME B on A.BeneficiaryInstitution=B.SwiftField
                            where A.BeneficiaryInstitution like':58%' and A.Country_58A is NULL

                            UPDATE CALYPSO_PAYMENTS SET Field_58A=BeneficiaryInstitution,Country_58A=SUBSTRING(BeneficiaryInstitution,5,2)
                            where ISNULL(BeneficiaryInstitution,'') not like':58%' and LEN(BeneficiaryInstitution)>=6 and  Country_58A is NULL"
        cmd.ExecuteNonQuery()

        Console.WriteLine("Insert new Synonyms in CALYPSO_PAYMENTS_SYNONYME")
        cmd.CommandText = "INSERT INTO CALYPSO_PAYMENTS_SYNONYME
		                   (SwiftField)
                SELECT DISTINCT IntermediaryInstitution from CALYPSO_PAYMENTS
			                where IntermediaryInstitution like ':56%' and IntermediaryInstitution not in (Select SwiftField from CALYPSO_PAYMENTS_SYNONYME)
                UNION ALL
                SELECT DISTINCT AccountWithInstitution from CALYPSO_PAYMENTS
			                where AccountWithInstitution  like ':57%' and AccountWithInstitution  not in (Select SwiftField from CALYPSO_PAYMENTS_SYNONYME)
                UNION ALL
                SELECT DISTINCT BeneficiaryInstitution from CALYPSO_PAYMENTS
			                where BeneficiaryInstitution  like ':58%' and BeneficiaryInstitution not in (Select SwiftField from CALYPSO_PAYMENTS_SYNONYME)"
        cmd.ExecuteNonQuery()


        cmd.Connection.Close()

    End Sub

End Module
